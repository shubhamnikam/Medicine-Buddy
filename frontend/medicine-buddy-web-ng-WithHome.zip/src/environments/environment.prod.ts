export const environment = {
  production: true,
  API_ENDPOINT: 'http://localhost:5000/',
};
